/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package netbeansproject;
import java.sql.SQLException;
/**
 *
 * created by Muhammad Hanif Fadhil bin Zakaria (78245)
 * tested by Nurshahira binti Nabi (80800)
 */
public interface graph {
    void showMonthly() throws SQLException;
}
