    /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package netbeansproject;

import java.sql.SQLException;
/**
 *
 * created by Nurshahira binti Nabi (80800)
 * tested by Hana Saffiyya binti Ahmad Nozal (78013)
 */
public interface summary {
    void sumBasedOnType()throws SQLException;
}
