/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package netbeansproject;
//import javax.swing.*;
import java.sql.SQLException;

/**
 *created by Nurshahira binti Nabi (80800) 
 *tested by Muhammad Hanif Fadhil bin Zakaria (78245)
 */
public class NetbeansProject{

    /**
     * @param args the command line arguments
     * @throws java.sql.SQLException
     */


    public static void main(String[] args) throws SQLException {
          UNIbudgettracker unib=new UNIbudgettracker();
          unib.setVisible(true);
    }

    
}
