/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package netbeansproject;

/**
 *
 * created by Ngu Keh Cong (80369)
 * tested by Nurshahira binti Nabi (80800)
 */
public interface SubmitData {
    void submit();
}
